"""
__COMMAND_DESCRIPTION__

@author __AUTHOR__ <__AUTHOR_EMAIL__>

Copyright (C) __YEAR__ __COPY_RIGHT__
"""
__version__ = "0.0.0"
