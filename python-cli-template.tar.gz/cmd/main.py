"""
__COMMAND_DESCRIPTION__

@author __AUTHOR__ <__AUTHOR_EMAIL__>

Copyright (C) __YEAR__ __COPY_RIGHT__
"""


def main():
    pass


if __name__ == "__main__":
    main()  # pylint: disable=no-value-for-parameter
