"""
calculate distance between node ids

@author Shigenori Otake <shigenori.otake@ghelia.com>

Copyright (C) 2019 GHELIA Inc.
"""
__version__ = "0.0.0"
