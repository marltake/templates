"""
calculate distance between node ids

@author Shigenori Otake <shigenori.otake@ghelia.com>

Copyright (C) 2019 GHELIA Inc.
"""
import click


@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx):
    if ctx.invoked_subcommand is None:
        print(ctx.get_help())
    else:
        print("gonna invoke", ctx.invoked_subcommand)


@main.command(help="base58 decode ids")
@click.argument("textid")
@click.argument("binid", required=False)
def decode(textid, binid):
    print(textid, binid)


@main.command(help="calculate distance between ids")
@click.argument("binid")
@click.argument("bindistance", required=False)
def calcdist(binid, bindistance):
    print(binid, bindistance)


if __name__ == "__main__":
    main()  # pylint: disable=no-value-for-parameter
