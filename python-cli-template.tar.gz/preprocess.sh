#!/bin/bash
# tmpfile=$(mktemp)
# function rm_tmpfile {
#   [[ -f "$tmpfile" ]] && rm -f "$tmpfile"
# }
# trap rm_tmpfile EXIT
# trap 'trap - EXIT; rm_tmpfile; exit -1' INT PIPE TERM

for f in Pipfile setup.py setup.cfg cmd/__init__.py cmd/main.py
do
sed -i .workingbackup \
-e 's/COMMAND_NAME//' \
-e 's/__COMMAND_DESCRIPTION__//' \
-e 's/__AUTHOR__//' \
-e 's/__AUTHOR_EMAIL__//' \
-e 's/__YEAR__//' \
-e 's/__COPY_RIGHT__//' \
$f
done
find . -name '*.workingbackup' | xargs rm
